# tipos_fuego > tipos_fuego
https://universe.roboflow.com/brayanordonez/tipos_fuego

Provided by a Roboflow user
License: CC BY 4.0

